<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.2" name="grid" tilewidth="32" tileheight="32" tilecount="1024" columns="32">
 <image source="../images/grid.png" width="1024" height="1024"/>
</tileset>
